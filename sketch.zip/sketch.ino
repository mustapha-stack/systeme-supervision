#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>

// ===========================
// A MODIFIER : identifiants des capteurs
// ===========================
// Un DHT22 mesure DEUX grandeurs : il faut donc DEUX capteurs dans la base.
// Ces identifiants doivent etre exactement ceux crees dans le tableau de bord
// (champ "Identifiant" du capteur). Le sujet MQTT en est deduit :
//   supervision/<identifiant>
const char* SENSOR_ID_TEMPERATURE = "temp-b127";
const char* SENSOR_ID_HUMIDITY    = "hum-b127";

// ===========================
// DHT22
// ===========================
#define DHT_PIN 4
#define DHT_TYPE DHT22

DHT dht(DHT_PIN, DHT_TYPE);

// ===========================
// WiFi Velxio
// ===========================
const char* WIFI_SSID = "Velxio-GUEST";

// ===========================
// A MODIFIER : courtier MQTT (EMQX), TLS
// ===========================
const char* MQTT_HOST = "v7276b11.ala.us-east-1.emqxsl.com";
const int   MQTT_PORT = 8883;
const char* MQTT_USER = "ulysse";
const char* MQTT_PASS = "ulysse";

// Identifiant du client MQTT : doit etre unique sur le courtier.
const char* MQTT_CLIENT_ID = "carte-esp32-01";

// ===========================
// MQTT client
// ===========================
WiFiClientSecure secureClient;
PubSubClient mqttClient(secureClient);


void connectWiFi() {
  Serial.print("Connexion WiFi");

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID);

  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WiFi connecte !");
  Serial.print("IP : ");
  Serial.println(WiFi.localIP());
}


void connectMQTT() {
  while (!mqttClient.connected()) {

    Serial.print("Connexion MQTT TLS...");

    if (mqttClient.connect(MQTT_CLIENT_ID, MQTT_USER, MQTT_PASS)) {
      Serial.println(" connecte !");
    } else {
      Serial.print(" erreur=");
      Serial.println(mqttClient.state());
      delay(2000);
    }
  }
}


// Publie une mesure sur le sujet supervision/<sensorId>
// avec la charge utile { "value": <nombre> }.
bool publishMeasure(const char* sensorId, float value) {
  char topic[96];
  snprintf(topic, sizeof(topic), "supervision/%s", sensorId);

  char payload[40];
  snprintf(payload, sizeof(payload), "{\"value\":%.2f}", value);

  bool success = mqttClient.publish(topic, payload);

  Serial.print(topic);
  Serial.print(" ");
  Serial.print(payload);
  Serial.println(success ? " : OK" : " : ERREUR");

  return success;
}


void setup() {
  Serial.begin(115200);

  // Initialisation DHT22
  dht.begin();

  // WiFi
  connectWiFi();

  // TLS sans validation du certificat
  // OK pour simulation/test
  secureClient.setInsecure();

  // MQTT
  mqttClient.setServer(MQTT_HOST, MQTT_PORT);

  Serial.println("DHT22 initialise.");
}


void loop() {

  if (WiFi.status() != WL_CONNECTED) {
    connectWiFi();
  }

  if (!mqttClient.connected()) {
    connectMQTT();
  }

  mqttClient.loop();

  // ===========================
  // Lecture DHT22 (deux grandeurs)
  // ===========================
  float temperature = dht.readTemperature();
  float humidity    = dht.readHumidity();

  // Une grandeur illisible n'empeche pas l'autre d'etre envoyee.
  if (isnan(temperature)) {
    Serial.println("Erreur lecture temperature");
  } else {
    publishMeasure(SENSOR_ID_TEMPERATURE, temperature);
  }

  if (isnan(humidity)) {
    Serial.println("Erreur lecture humidite");
  } else {
    publishMeasure(SENSOR_ID_HUMIDITY, humidity);
  }

  // Le DHT22 ne peut pas etre lu plus d'une fois toutes les 2 secondes.
  delay(2000);
}